-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 10 juin 2025 à 17:48
-- Version du serveur : 8.0.31
-- Version de PHP : 8.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `codefarmer`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `admin_mail` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `admin_password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_mail`, `admin_password`) VALUES
(1, 'scriptenjoyer', 'scriptenjoyer@gmail.com', 'admin2025');

-- --------------------------------------------------------

--
-- Structure de la table `candidature`
--

DROP TABLE IF EXISTS `candidature`;
CREATE TABLE IF NOT EXISTS `candidature` (
  `candid_id` int NOT NULL AUTO_INCREMENT,
  `candid_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `candid_ref` int NOT NULL,
  `candid_fname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `candid_lname` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `candid_mail` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `candid_tel` int NOT NULL,
  `candid_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `candid_cv` text COLLATE utf8mb4_general_ci NOT NULL,
  `candid_lm` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`candid_id`),
  UNIQUE KEY `candid_ref` (`candid_ref`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `candidature`
--

INSERT INTO `candidature` (`candid_id`, `candid_title`, `candid_ref`, `candid_fname`, `candid_lname`, `candid_mail`, `candid_tel`, `candid_description`, `candid_cv`, `candid_lm`) VALUES
(6, 'Développeur Web Backend ', 43207, 'Hiroux', 'Jérémy', 'j.hiroux456@gmail.com', 2147483647, 'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm', 'assets/candidImg/73_67fe1e568c04f7.84349648_cv.png', 'assets/candidImg/73_67fe1e568c04f7.84349648_lm.rtf');

-- --------------------------------------------------------

--
-- Structure de la table `comentaire`
--

DROP TABLE IF EXISTS `comentaire`;
CREATE TABLE IF NOT EXISTS `comentaire` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_auteur` int NOT NULL,
  `name_auteur` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_coment` int NOT NULL,
  `contenu` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `comentaire`
--

INSERT INTO `comentaire` (`id`, `id_auteur`, `name_auteur`, `id_coment`, `contenu`) VALUES
(49, 73, 'Jerem', 125, 'ok');

-- --------------------------------------------------------

--
-- Structure de la table `enterprise`
--

DROP TABLE IF EXISTS `enterprise`;
CREATE TABLE IF NOT EXISTS `enterprise` (
  `id_enterprise` int NOT NULL AUTO_INCREMENT,
  `enterprise_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `enterprise_mail` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `enterprise_password` text COLLATE utf8mb4_general_ci NOT NULL,
  `enterprise_number` int NOT NULL,
  `enterprise_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `enterprise_sector` text COLLATE utf8mb4_general_ci NOT NULL,
  `enterprise_link` text COLLATE utf8mb4_general_ci,
  `enterprise_banner` int NOT NULL,
  `enterprise_location` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `date_inscription` datetime NOT NULL,
  `confirmkey` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `confirm` int NOT NULL,
  PRIMARY KEY (`id_enterprise`),
  UNIQUE KEY `enterprise_name` (`enterprise_name`),
  UNIQUE KEY `enterprise_number` (`enterprise_number`),
  UNIQUE KEY `enterprise_mail` (`enterprise_mail`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `enterprise`
--

INSERT INTO `enterprise` (`id_enterprise`, `enterprise_name`, `enterprise_mail`, `enterprise_password`, `enterprise_number`, `enterprise_description`, `enterprise_sector`, `enterprise_link`, `enterprise_banner`, `enterprise_location`, `date_inscription`, `confirmkey`, `confirm`) VALUES
(3, 'Tryhard Studio', 'constelium9@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$dFd1MkM4d1EyZ1lMQjJNcg$iaDL+lLeh5DGdvdMJUHOV+QUGWkf3aZ342t40eiimx4', 2147483647, 'Tryhard Studio est une agence de développement web innovante, spécialisée dans la création de sites performants, modernes et sur-mesure.\r\nNous accompagnons startups, PME et grandes entreprises dans la réalisation de leurs projets digitaux, en combinant créativité, expertise technique et passion du détail.\r\nNotre mission : propulser votre présence en ligne et booster votre croissance avec des solutions web à la hauteur de vos ambitions.', 'Developpement web Securite', 'fefsfesfsfsfsefsfs', 3, 'Luxembourg', '2025-03-26 00:00:00', '4169686', 1);

-- --------------------------------------------------------

--
-- Structure de la table `msgprive`
--

DROP TABLE IF EXISTS `msgprive`;
CREATE TABLE IF NOT EXISTS `msgprive` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_destinataire` int NOT NULL,
  `id_expediteur` int NOT NULL,
  `msg_date` datetime NOT NULL,
  `statut` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `msgprive`
--

INSERT INTO `msgprive` (`id`, `message`, `id_destinataire`, `id_expediteur`, `msg_date`, `statut`) VALUES
(226, 'rgdg', 73, 74, '2025-05-29 12:43:34', 0),
(227, 'Salut ca vas ?', 73, 74, '2025-05-29 12:43:52', 0),
(228, 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 73, 74, '2025-05-29 12:44:08', 0),
(229, 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 73, 74, '2025-05-29 12:45:13', 0),
(230, 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 73, 74, '2025-05-29 12:46:22', 0),
(231, 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', 73, 74, '2025-05-29 12:46:40', 0),
(232, 'gsegsgfs', 74, 73, '2025-05-29 12:53:49', 0),
(233, 'ggugdudgs', 73, 74, '2025-05-29 12:58:11', 0),
(234, 'ow', 74, 73, '2025-05-30 10:48:47', 0);

-- --------------------------------------------------------

--
-- Structure de la table `publications`
--

DROP TABLE IF EXISTS `publications`;
CREATE TABLE IF NOT EXISTS `publications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titre` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contenu` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cd_html` text COLLATE utf8mb4_general_ci,
  `cd_css` text COLLATE utf8mb4_general_ci,
  `cd_js` text COLLATE utf8mb4_general_ci,
  `id_auteur` int NOT NULL,
  `nom_auteur` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_publication` text COLLATE utf8mb4_general_ci NOT NULL,
  `img_publication` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `publications`
--

INSERT INTO `publications` (`id`, `titre`, `contenu`, `cd_html`, `cd_css`, `cd_js`, `id_auteur`, `nom_auteur`, `date_publication`, `img_publication`) VALUES
(125, 'My tabs', 'création d\'un menu tabs', '&lt;div class=&quot;tab&quot;&gt;\r\n  &lt;button class=&quot;tablinks&quot; onclick=&quot;openCity(event, &#039;London&#039;)&quot;&gt;London&lt;/button&gt;\r\n  &lt;button class=&quot;tablinks&quot; onclick=&quot;openCity(event, &#039;Paris&#039;)&quot;&gt;Paris&lt;/button&gt;\r\n  &lt;button class=&quot;tablinks&quot; onclick=&quot;openCity(event, &#039;Tokyo&#039;)&quot;&gt;Tokyo&lt;/button&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;!-- Tab content --&gt;\r\n&lt;div id=&quot;London&quot; class=&quot;tabcontent&quot;&gt;\r\n  &lt;h3&gt;London&lt;/h3&gt;\r\n  &lt;p&gt;London is the capital city of England.&lt;/p&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;div id=&quot;Paris&quot; class=&quot;tabcontent&quot;&gt;\r\n  &lt;h3&gt;Paris&lt;/h3&gt;\r\n  &lt;p&gt;Paris is the capital of France.&lt;/p&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;div id=&quot;Tokyo&quot; class=&quot;tabcontent&quot;&gt;\r\n  &lt;h3&gt;Tokyo&lt;/h3&gt;\r\n  &lt;p&gt;Tokyo is the capital of Japan.&lt;/p&gt;\r\n&lt;/div&gt;', '.tab {\r\n  overflow: hidden;\r\n  border: 1px solid #ccc;\r\n  background-color: #f1f1f1;\r\n}\r\n\r\n/* Style the buttons that are used to open the tab content */\r\n.tab button {\r\n  background-color: inherit;\r\n  float: left;\r\n  border: none;\r\n  outline: none;\r\n  cursor: pointer;\r\n  padding: 14px 16px;\r\n  transition: 0.3s;\r\n}\r\n\r\n/* Change background color of buttons on hover */\r\n.tab button:hover {\r\n  background-color: #ddd;\r\n}\r\n\r\n/* Create an active/current tablink class */\r\n.tab button.active {\r\n  background-color: #ccc;\r\n}\r\n\r\n/* Style the tab content */\r\n.tabcontent {\r\n  display: none;\r\n  padding: 6px 12px;\r\n  border: 1px solid #ccc;\r\n  border-top: none;\r\n}', 'function openCity(evt, cityName) {\r\n  // Declare all variables\r\n  var i, tabcontent, tablinks;\r\n\r\n  // Get all elements with class=&quot;tabcontent&quot; and hide them\r\n  tabcontent = document.getElementsByClassName(&quot;tabcontent&quot;);\r\n  for (i = 0; i &lt; tabcontent.length; i++) {\r\n    tabcontent[i].style.display = &quot;none&quot;;\r\n  }\r\n\r\n  // Get all elements with class=&quot;tablinks&quot; and remove the class &quot;active&quot;\r\n  tablinks = document.getElementsByClassName(&quot;tablinks&quot;);\r\n  for (i = 0; i &lt; tablinks.length; i++) {\r\n    tablinks[i].className = tablinks[i].className.replace(&quot; active&quot;, &quot;&quot;);\r\n  }\r\n\r\n  // Show the current tab, and add an &quot;active&quot; class to the button that opened the tab\r\n  document.getElementById(cityName).style.display = &quot;block&quot;;\r\n  evt.currentTarget.className += &quot; active&quot;;\r\n}', 73, 'Jerem', '20/03/2025', 'portable.webp'),
(126, 'Side barre avec icônes', 'Création d\'une sidebarre avec des icone', '&lt;!-- Load an icon library --&gt;\r\n&lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css&quot;&gt;\r\n\r\n&lt;!-- The sidebar --&gt;\r\n&lt;div class=&quot;sidebar&quot;&gt;\r\n  &lt;a href=&quot;#home&quot;&gt;&lt;i class=&quot;fa fa-fw fa-home&quot;&gt;&lt;/i&gt; Home&lt;/a&gt;\r\n  &lt;a href=&quot;#services&quot;&gt;&lt;i class=&quot;fa fa-fw fa-wrench&quot;&gt;&lt;/i&gt; Services&lt;/a&gt;\r\n  &lt;a href=&quot;#clients&quot;&gt;&lt;i class=&quot;fa fa-fw fa-user&quot;&gt;&lt;/i&gt; Clients&lt;/a&gt;\r\n  &lt;a href=&quot;#contact&quot;&gt;&lt;i class=&quot;fa fa-fw fa-envelope&quot;&gt;&lt;/i&gt; Contact&lt;/a&gt;\r\n&lt;/div&gt;', '/* Style the sidebar - fixed full height */\r\n.sidebar {\r\n  height: 100%;\r\n  width: 160px;\r\n  position: fixed;\r\n  z-index: 1;\r\n  top: 0;\r\n  left: 0;\r\n  background-color: #111;\r\n  overflow-x: hidden;\r\n  padding-top: 16px;\r\n}\r\n\r\n/* Style sidebar links */\r\n.sidebar a {\r\n  padding: 6px 8px 6px 16px;\r\n  text-decoration: none;\r\n  font-size: 20px;\r\n  color: #818181;\r\n  display: block;\r\n}\r\n\r\n/* Style links on mouse-over */\r\n.sidebar a:hover {\r\n  color: #f1f1f1;\r\n}\r\n\r\n/* Style the main content */\r\n.main {\r\n  margin-left: 160px; /* Same as the width of the sidenav */\r\n  padding: 0px 10px;\r\n}\r\n\r\n/* Add media queries for small screens (when the height of the screen is less than 450px, add a smaller padding and font-size) */\r\n@media screen and (max-height: 450px) {\r\n  .sidebar {padding-top: 15px;}\r\n  .sidebar a {font-size: 18px;}\r\n}', 'no js!', 73, 'Jerem', '20/03/2025', 'bgone.jpg'),
(128, 'Off canvas', 'Création d\'un menu off canvas', '&lt;div id=&quot;mySidenav&quot; class=&quot;sidenav&quot;&gt;\r\n  &lt;a href=&quot;javascript:void(0)&quot; class=&quot;closebtn&quot; onclick=&quot;closeNav()&quot;&gt;&amp;times;&lt;/a&gt;\r\n  &lt;a href=&quot;#&quot;&gt;About&lt;/a&gt;\r\n  &lt;a href=&quot;#&quot;&gt;Services&lt;/a&gt;\r\n  &lt;a href=&quot;#&quot;&gt;Clients&lt;/a&gt;\r\n  &lt;a href=&quot;#&quot;&gt;Contact&lt;/a&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;!-- Use any element to open the sidenav --&gt;\r\n&lt;span onclick=&quot;openNav()&quot;&gt;open&lt;/span&gt;\r\n\r\n&lt;!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page --&gt;\r\n&lt;div id=&quot;main&quot;&gt;\r\n  ...\r\n&lt;/div&gt;', '/* The side navigation menu */\r\n.sidenav {\r\n  height: 100%; /* 100% Full-height */\r\n  width: 0; /* 0 width - change this with JavaScript */\r\n  position: fixed; /* Stay in place */\r\n  z-index: 1; /* Stay on top */\r\n  top: 0;\r\n  left: 0;\r\n  background-color: #111; /* Black*/\r\n  overflow-x: hidden; /* Disable horizontal scroll */\r\n  padding-top: 60px; /* Place content 60px from the top */\r\n  transition: 0.5s; /* 0.5 second transition effect to slide in the sidenav */\r\n}\r\n\r\n/* The navigation menu links */\r\n.sidenav a {\r\n  padding: 8px 8px 8px 32px;\r\n  text-decoration: none;\r\n  font-size: 25px;\r\n  color: #818181;\r\n  display: block;\r\n  transition: 0.3s;\r\n}\r\n\r\n/* When you mouse over the navigation links, change their color */\r\n.sidenav a:hover {\r\n  color: #f1f1f1;\r\n}\r\n\r\n/* Position and style the close button (top right corner) */\r\n.sidenav .closebtn {\r\n  position: absolute;\r\n  top: 0;\r\n  right: 25px;\r\n  font-size: 36px;\r\n  margin-left: 50px;\r\n}\r\n\r\n/* Style page content - use this if you want to push the page content to the right when you open the side navigation */\r\n#main {\r\n  transition: margin-left .5s;\r\n  padding: 20px;\r\n}\r\n\r\n/* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */\r\n@media screen and (max-height: 450px) {\r\n  .sidenav {padding-top: 15px;}\r\n  .sidenav a {font-size: 18px;}\r\n}\r\n', '/* Set the width of the side navigation to 250px and the left margin of the page content to 250px */\r\nfunction openNav() {\r\n  document.getElementById(&quot;mySidenav&quot;).style.width = &quot;250px&quot;;\r\n  document.getElementById(&quot;main&quot;).style.marginLeft = &quot;250px&quot;;\r\n}\r\n\r\n/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */\r\nfunction closeNav() {\r\n  document.getElementById(&quot;mySidenav&quot;).style.width = &quot;0&quot;;\r\n  document.getElementById(&quot;main&quot;).style.marginLeft = &quot;0&quot;;\r\n}', 73, 'Jerem', '20/03/2025', '76352fb6ecdd259216b4808abb9c40aa.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `recrutement`
--

DROP TABLE IF EXISTS `recrutement`;
CREATE TABLE IF NOT EXISTS `recrutement` (
  `id_recruitment` int NOT NULL AUTO_INCREMENT,
  `job_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `job_location` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `job_time` int NOT NULL,
  `job_contract` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `job_device` enum('euro','usd') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_salary` int NOT NULL,
  `job_offer_author` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `job_author_id` int NOT NULL,
  `job_identification` int NOT NULL,
  PRIMARY KEY (`id_recruitment`),
  UNIQUE KEY `job_identification` (`job_identification`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `recrutement`
--

INSERT INTO `recrutement` (`id_recruitment`, `job_title`, `job_description`, `job_location`, `job_time`, `job_contract`, `job_device`, `job_salary`, `job_offer_author`, `job_author_id`, `job_identification`) VALUES
(5, 'Développeur Web Backend ', 'Nous recherchons un Développeur Web Back-end talentueux et motivé pour rejoindre notre équipe technique. Vous participerez activement au développement, à l’optimisation et à la maintenance de nos applications web internes et clients.', 'Luxembourg', 35, 'cdi', 'euro', 2800, 'Tryhard studio', 3, 43207);

-- --------------------------------------------------------

--
-- Structure de la table `secure_tools`
--

DROP TABLE IF EXISTS `secure_tools`;
CREATE TABLE IF NOT EXISTS `secure_tools` (
  `scrt_id` int NOT NULL AUTO_INCREMENT,
  `scrt_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `scrt_descript` text COLLATE utf8mb4_general_ci NOT NULL,
  `scrt_link` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `scrt_logo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`scrt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `secure_tools`
--

INSERT INTO `secure_tools` (`scrt_id`, `scrt_name`, `scrt_descript`, `scrt_link`, `scrt_logo`) VALUES
(1, 'Burp Suite', 'Outil complet pour l&#039;audit de sécurité des applications web, avec des fonctionnalités d&#039;interception, de scan actif/passif, et d&#039;extensions personnalisables.', 'https://portswigger.net/burp', 'assets/secureToolLogo/1_680d40536bdeb6.65095494_tool.png'),
(2, 'OWASP ZAP (Zed Attack Proxy)', 'Solution open source gratuite, idéale pour détecter automatiquement les vulnérabilités comme les injections SQL ou XSS.', 'https://www.zaproxy.org/', 'assets/secureToolLogo/1_680d41d8ba72d6.48018662_tool.png'),
(3, 'Acunetix', 'Scanner automatisé performant, capable de détecter plus de 7 000 vulnérabilités, avec intégration CI/CD et rapports détaillés.', 'https://www.acunetix.com/', 'assets/secureToolLogo/1_680d4390af3d12.05450375_tool.png'),
(4, 'Imperva Secure CDN', 'Solution cloud combinant CDN, WAF et protection API, avec déploiement rapide et protection contre les menaces modernes.', 'https://www.imperva.com/products/secure-cdn/', 'assets/secureToolLogo/1_680d45005d4472.97559637_tool.png'),
(5, 'Qualys Web Application Scanning (WAS)', 'Plateforme cloud pour le scan continu des vulnérabilités, avec patchs virtuels et intégration DevSecOps.', 'https://www.qualys.com/apps/web-app-scanning/', 'assets/secureToolLogo/1_680d45e93f5b90.65731691_tool.png');

-- --------------------------------------------------------

--
-- Structure de la table `tendance_ai`
--

DROP TABLE IF EXISTS `tendance_ai`;
CREATE TABLE IF NOT EXISTS `tendance_ai` (
  `id_ai` int NOT NULL AUTO_INCREMENT,
  `ai_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `ai_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `ai_link` varchar(2048) COLLATE utf8mb4_general_ci NOT NULL,
  `ai_logo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_ai`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `tendance_ai`
--

INSERT INTO `tendance_ai` (`id_ai`, `ai_name`, `ai_description`, `ai_link`, `ai_logo`) VALUES
(7, 'Perplexity AI', 'Un moteur de recherche conversationnel qui fournit des réponses sourcées en temps réel.', 'https://www.perplexity.ai', 'assets/aiLogo/1_680c62c1ceafd5.15580519_ia.png'),
(8, 'Google Gemini', 'L&#039;IA de Google intégrée à la recherche, utile pour la rédaction et la synthèse d&#039;informations.', 'https://gemini.google.com', 'assets/aiLogo/1_680c6479118649.70966330_ia.png'),
(9, 'Synthesia', ' Permet de créer des vidéos professionnelles avec des avatars et des voix synthétiques.', ' https://www.synthesia.io​', 'assets/aiLogo/1_680c6c672f8603.63888062_ia.png'),
(11, 'Midjourney', 'Crée des illustrations artistiques et réalistes à partir de commandes textuelles.', ' https://www.midjourney.com', 'assets/aiLogo/1_680c6d1378ee25.20295986_ia.png'),
(13, 'ChatGPT', ' Un assistant polyvalent pour la rédaction, le codage, la recherche et plus encore.', 'https://chat.openai.com', 'assets/aiLogo/1_680c6e17edbd43.89610068_ia.png');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `userPassword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_naissance` date NOT NULL,
  `ville` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `genre` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_inscription` datetime NOT NULL,
  `statut` int DEFAULT NULL,
  `avatar` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `skill` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `lien_github` text COLLATE utf8mb4_general_ci,
  `lien_web` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `youtube` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `confirmkey` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirm` int NOT NULL,
  `user_ip` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `userName`, `mail`, `userPassword`, `date_naissance`, `ville`, `genre`, `date_inscription`, `statut`, `avatar`, `skill`, `lien_github`, `lien_web`, `youtube`, `confirmkey`, `confirm`, `user_ip`) VALUES
(73, 'Jerem', 'j.hiroux456@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$ZFBDUDFWQkptTmtVOXVVVA$pG09DYyx+srv4zi+Lzx/7A2mwSVoe5I1mxWaCUB/Mto', '1989-01-13', 'Bruxelles', 'Homme', '2025-03-20 00:00:00', NULL, '73.webp', 'html5 css3 javascript php mysql nodejs bootstrap react github gitkraken', 'https://github.com/apexdevweb', 'https://apexdevweb.github.io/ScriptEnjoyer.github.io/', 'https://www.youtube.com/@ScriptEnjoyer-p4r', '4313849', 1, ''),
(74, 'caro', 'apexdevweb@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$aFVsWnZwYUk2T1dIai5LbA$JZUK4vKbSPFdOqekXWoC0QwiV578kLHmHO0kETx2sF0', '1997-03-29', 'Hainaut', 'Femme', '2025-05-29 00:00:00', NULL, '74.jpg', 'html5 css3 javascript nodejs react vueJs', '', '', '', '5653438', 1, '');

-- --------------------------------------------------------

--
-- Structure de la table `visites`
--

DROP TABLE IF EXISTS `visites`;
CREATE TABLE IF NOT EXISTS `visites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL,
  `consulted_profile_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `visites`
--

INSERT INTO `visites` (`id`, `date`, `consulted_profile_id`) VALUES
(117, '2025-06-10 17:03:33', 74),
(118, '2025-06-10 17:03:39', 74),
(119, '2025-06-10 17:04:25', 73);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
